package com.pojavoptimizer.mod.mixin;

import net.minecraft.client.render.BufferBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.pojavoptimizer.mod.memory.RecyclableVertexBuilder;
import java.nio.ByteBuffer;

@Mixin(value = BufferBuilder.class, priority = 900)
public abstract class BufferBuilderMixin {

    @Shadow
    private ByteBuffer buffer;

    @Inject(method = "grow", at = @At("HEAD"), cancellable = true, require = 0)
    private void injectPooledBuffer(int size, CallbackInfo info) {
        try {
            if (this.buffer == null) {
                this.buffer = RecyclableVertexBuilder.acquireBuffer();
                info.cancel();
            }
        } catch (Throwable t) {
            System.err.println("[ApexOptimizer] Resizing BufferBuilder failed! Invoking vanilla fallback: " + t.getMessage());
        }
    }

    @Inject(method = "end", at = @At("TAIL"), require = 0)
    private void releaseBufferToPool(CallbackInfoReturnable<?> info) {
        try {
            if (this.buffer != null) {
                RecyclableVertexBuilder.releaseBuffer(this.buffer);
                this.buffer = null;
            }
        } catch (Throwable t) {
            System.err.println("[ApexOptimizer] Failed to release buffer to pool: " + t.getMessage());
        }
    }
}
