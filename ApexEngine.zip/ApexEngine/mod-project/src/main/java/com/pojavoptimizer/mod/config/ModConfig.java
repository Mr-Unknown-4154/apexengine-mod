package com.pojavoptimizer.mod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Keeps performance configuration fields.
 * Reads and writes JSON format to local storage: .minecraft/config/apexengine.json
 */
public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "apexengine.json");

    public int cpuThreads = 4;
    public int ramUsageThreshold = 80;
    public boolean maximizeGpu = true;
    public boolean enableOcclusionCulling = true;

    private static ModConfig instance;

    public static ModConfig getInstance() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                instance = GSON.fromJson(reader, ModConfig.class);
            } catch (IOException e) {
                System.err.println("[ApexEngine] Failed to load configuration file: " + e.getMessage());
                instance = new ModConfig();
            }
        } else {
            instance = new ModConfig();
            save();
        }
    }

    public static void save() {
        if (instance == null) {
            instance = new ModConfig();
        }
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(instance, writer);
        } catch (IOException e) {
            System.err.println("[ApexEngine] Failed to save configuration file: " + e.getMessage());
        }
    }
}
