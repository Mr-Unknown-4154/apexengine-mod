package com.pojavoptimizer.mod.mixin;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.pojavoptimizer.mod.threading.ChunkUpdateScheduler;
import com.pojavoptimizer.mod.threading.ChunkUpdateScheduler.PrioritizedRebuildTask;

@Mixin(value = WorldRenderer.class, priority = 900)
public class WorldRendererMixin {

    @Inject(method = "isChunkInvisible", at = @At("HEAD"), cancellable = true, require = 0)
    private void injectOcclusionCulling(ChunkBuilder.BuiltChunk chunk, Frustum frustum, CallbackInfoReturnable<Boolean> info) {
        try {
            int baseDist = 12;
            try {
                baseDist = net.minecraft.client.MinecraftClient.getInstance().options.getClampedViewDistance();
            } catch (Throwable ignore) {
                try {
                    baseDist = (Integer) net.minecraft.client.MinecraftClient.getInstance().options.getClass().getField("viewDistance").get(net.minecraft.client.MinecraftClient.getInstance().options);
                } catch (Throwable ignore2) {}
            }
            double maxAllowedDistanceSq = com.pojavoptimizer.mod.thermal.ThermalGuard.getThrottledRenderDistance(baseDist) * 16.0;
            maxAllowedDistanceSq = maxAllowedDistanceSq * maxAllowedDistanceSq;
            if (chunk.getSquaredDistanceToCamera() > maxAllowedDistanceSq) {
                info.setReturnValue(true);
                info.cancel();
                return;
            }
        } catch (Throwable t) {
            com.pojavoptimizer.mod.ApexEngine.LOGGER.error("Culling system driver exception, falling back to vanilla checks!", t);
        }
    }

    @Inject(method = "scheduleChunkRebuild", at = @At("HEAD"), cancellable = true, require = 0)
    private void injectMultiThreadedRebuild(ChunkBuilder.BuiltChunk chunk, CallbackInfo info) {
        try {
            if (com.pojavoptimizer.mod.ApexEngine.enableMultiThreadedRebuild) {
                double sqDistance = chunk.getSquaredDistanceToCamera();
                boolean inFrustum = true;
                
                String chunkId = chunk.toString();

                ChunkUpdateScheduler.submitSecure(chunkId, new PrioritizedRebuildTask(sqDistance, inFrustum) {
                    @Override
                    public void run() {
                        try {
                            chunk.rebuildImmediately(); 
                        } catch (Throwable meshErr) {
                            com.pojavoptimizer.mod.ApexEngine.LOGGER.error("Background chunk rebuild error on " + chunkId + ", fallback queued.", meshErr);
                        }
                    }
                });

                info.cancel();
            }
        } catch (Throwable t) {
            com.pojavoptimizer.mod.ApexEngine.LOGGER.error("Failed to schedule multi-threaded rebuild, using vanilla synchronous pipeline.", t);
        }
    }
}
