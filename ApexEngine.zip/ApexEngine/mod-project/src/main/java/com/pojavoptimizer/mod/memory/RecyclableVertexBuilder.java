package com.pojavoptimizer.mod.memory;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GC-Free Memory Pooling for Chunk Meshes with OOM prevention checks.
 */
public class RecyclableVertexBuilder {
    private static final Logger LOGGER = LoggerFactory.getLogger("RecyclableVertexBuilder");

    private static final int BUFFER_CAPACITY = 256 * 1024; 
    private static final Queue<ByteBuffer> DIRECT_BUFFER_POOL = new ConcurrentLinkedQueue<>();
    private static final AtomicLong memorySavedBytes = new AtomicLong(0);
    private static final AtomicLong allocatedBuffers = new AtomicLong(0);

    public static void preallocatePools(int initialCount) {
        try {
            for (int i = 0; i < initialCount; i++) {
                ByteBuffer buffer = ByteBuffer.allocateDirect(BUFFER_CAPACITY).order(ByteOrder.nativeOrder());
                DIRECT_BUFFER_POOL.offer(buffer);
                allocatedBuffers.incrementAndGet();
            }
        } catch (OutOfMemoryError oom) {
            LOGGER.error("Pojav OOM Guard triggered during pre-allocation! Releasing pools early to prevent crash.");
            forceEvictPools();
        }
    }

    public static ByteBuffer acquireBuffer() {
        ByteBuffer buffer = DIRECT_BUFFER_POOL.poll();
        if (buffer == null) {
            try {
                buffer = ByteBuffer.allocateDirect(BUFFER_CAPACITY).order(ByteOrder.nativeOrder());
                allocatedBuffers.incrementAndGet();
            } catch (OutOfMemoryError oom) {
                LOGGER.error("CRITICAL: Out of memory in direct native allocation! Invoking pool cleanup...");
                forceEvictPools();
                return ByteBuffer.allocate(BUFFER_CAPACITY).order(ByteOrder.nativeOrder());
            }
        }
        buffer.clear();
        memorySavedBytes.addAndGet(BUFFER_CAPACITY);
        return buffer;
    }

    public static void releaseBuffer(ByteBuffer buffer) {
        if (buffer != null && buffer.isDirect() && DIRECT_BUFFER_POOL.size() < 128) {
            DIRECT_BUFFER_POOL.offer(buffer);
        }
    }

    public static void forceEvictPools() {
        DIRECT_BUFFER_POOL.clear();
        allocatedBuffers.set(0);
        System.gc();
    }

    public static double getSavedMemoryMB() {
        return memorySavedBytes.get() / (1024.0 * 1024.0);
    }
}
