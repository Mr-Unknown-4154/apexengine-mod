package com.pojavoptimizer.mod.threading;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Offloads compute-heavy Chunk Rebuilding and Tessellation from the Main Client Render Thread.
 * Default Minecraft blocks the OpenGL context thread to compile blocks into vertex data.
 * This scheduler distributes compilation across available ARM cores with Thread-Safety guards.
 */
public class ChunkUpdateScheduler {
    private static final Logger LOGGER = LoggerFactory.getLogger("ChunkUpdateScheduler");
    private static ExecutorService chunkRebuildExecutor;
    private static final AtomicInteger activeTasks = new AtomicInteger(0);
    
    // Thread safety guard: Tracks active thread compilations to prevent duplicate submissions or ConcurrentModException
    private static final ConcurrentHashMap<String, Future<?>> ACTIVE_SUBMISSIONS = new ConcurrentHashMap<>();
    
    /**
     * Initializes a thread pool designed for Android's BIG.little architecture.
     * Separates workers with appropriate thread priority to avoid starving the audio or main input threads.
     */
    public static synchronized void initialize(int threadCount) {
        if (chunkRebuildExecutor != null) {
            chunkRebuildExecutor.shutdown();
        }
        
        LOGGER.info("Configuring Custom Thread Pool for Chunk Rendering. Size: " + threadCount);
        
        // Custom thread factory to set custom priorities for Android thread scheduling
        ThreadFactory customFactory = new ThreadFactory() {
            private final AtomicInteger counter = new AtomicInteger(1);
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "Pojav-RenderWorker-" + counter.getAndIncrement());
                t.setPriority(6); // Touch fluidity priority
                t.setDaemon(true);
                return t;
            }
        };

        chunkRebuildExecutor = new ThreadPoolExecutor(
            threadCount,
            threadCount,
            60L, TimeUnit.SECONDS,
            new PriorityBlockingQueue<>(128),
            customFactory
        );
    }

    public static void submitSecure(String chunkPosId, PrioritizedRebuildTask task) {
        if (chunkRebuildExecutor == null || chunkRebuildExecutor.isShutdown()) {
            task.run(); // Fallback synchronously if pool is down
            return;
        }

        ACTIVE_SUBMISSIONS.compute(chunkPosId, (key, existingFuture) -> {
            if (existingFuture != null && !existingFuture.isDone()) {
                return existingFuture; // Skip duplicate to prevent race condition
            }

            activeTasks.incrementAndGet();
            return chunkRebuildExecutor.submit(() -> {
                try {
                    task.run();
                } catch (Throwable t) {
                    LOGGER.error("Race condition shield: Task compilation failed on chunk ID: " + chunkPosId, t);
                } finally {
                    activeTasks.decrementAndGet();
                    ACTIVE_SUBMISSIONS.remove(chunkPosId);
                }
            });
        });
    }

    public static int getActiveTaskCount() {
        return activeTasks.get();
    }

    public static void shutdown() {
        if (chunkRebuildExecutor != null) {
            chunkRebuildExecutor.shutdownNow();
        }
        ACTIVE_SUBMISSIONS.clear();
    }

    /**
     * Dynamically adjusts the thread pool size of the chunk rebuilding executor.
     * Prevents Android devices from heating up when the Thermal Guard triggers.
     */
    public static synchronized void setThreadCount(int threadCount) {
        if (chunkRebuildExecutor instanceof ThreadPoolExecutor) {
            ThreadPoolExecutor tpe = (ThreadPoolExecutor) chunkRebuildExecutor;
            if (threadCount < tpe.getCorePoolSize()) {
                tpe.setCorePoolSize(threadCount);
                tpe.setMaximumPoolSize(threadCount);
            } else {
                tpe.setMaximumPoolSize(threadCount);
                tpe.setCorePoolSize(threadCount);
            }
            LOGGER.info("[ChunkUpdateScheduler] Dynamic resize: CorePoolSize=" + tpe.getCorePoolSize() + ", MaxPoolSize=" + tpe.getMaximumPoolSize());
        }
    }

    public static abstract class PrioritizedRebuildTask implements Runnable, Comparable<PrioritizedRebuildTask> {
        private final double sqDistanceToPlayer;
        private final int priorityModifier; // lower = higher priority (e.g. view frustum overlap)

        public PrioritizedRebuildTask(double sqDistanceToPlayer, boolean isInFrustum) {
            this.sqDistanceToPlayer = sqDistanceToPlayer;
            this.priorityModifier = isInFrustum ? 0 : 1000;
        }

        @Override
        public int compareTo(PrioritizedRebuildTask other) {
            double thisPriority = this.sqDistanceToPlayer + (this.priorityModifier * 100);
            double otherPriority = other.sqDistanceToPlayer + (other.priorityModifier * 100);
            return Double.compare(thisPriority, otherPriority);
        }
    }
}
