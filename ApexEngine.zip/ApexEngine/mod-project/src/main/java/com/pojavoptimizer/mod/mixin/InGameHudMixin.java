package com.pojavoptimizer.mod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.font.TextRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.pojavoptimizer.mod.thermal.ThermalGuard;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    
    @Inject(method = "render", at = @At("TAIL"))
    private void drawThermalOverlay(Object drawContext, float tickDelta, CallbackInfo info) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options.hudHidden) return;
        
        TextRenderer textRenderer = client.textRenderer;
        if (textRenderer == null) return;
        
        ThermalGuard.ThermalState state = ThermalGuard.getCurrentState();
        float temp = ThermalGuard.getCurrentTemperature();
        
        String tempText = String.format("APEX THERMAL: %.1f°C", temp);
        String stateText = "COOL";
        int color = 0x00FF00;
        
        if (state == ThermalGuard.ThermalState.THROTTLED) {
            stateText = "THROTTLED (GUARD ACTIVE)";
            color = 0xFF3333;
        } else if (state == ThermalGuard.ThermalState.WARNING) {
            stateText = "WARM (WARNING)";
            color = 0xFFCC00;
        }
        
        String displayText = String.format("%s [%s]", tempText, stateText);
        
        try {
            if (drawContext != null) {
                drawContext.getClass()
                    .getMethod("drawTextWithShadow", TextRenderer.class, String.class, int.class, int.class, int.class)
                    .invoke(drawContext, textRenderer, displayText, 10, 10, color);
            }
        } catch (Throwable t) {
            try {
                textRenderer.drawWithShadow(new net.minecraft.client.util.math.MatrixStack(), displayText, 10.0f, 10.0f, color);
            } catch (Throwable t2) {}
        }
    }
}
