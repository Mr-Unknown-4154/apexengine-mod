package com.pojavoptimizer.mod.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GLES30;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.pojavoptimizer.mod.config.ModConfig;

@Mixin(value = RenderSystem.class, remap = false, priority = 900)
public class RenderSystemMixin {

    @Inject(method = "initRenderSystem", at = @At("TAIL"), require = 0)
    private static void optimizeGlesPipeline(CallbackInfo info) {
        try {
            RenderSystem.assertOnRenderThread();
            
            if (ModConfig.getInstance().maximizeGpu) {
                String driverVersion = GLES30.glGetString(GLES30.GL_VERSION);
                if (driverVersion != null) {
                    System.out.println("[ApexRenderSystem] Initializing optimization state on: " + driverVersion);
                }
                
                GLES30.glEnable(GLES30.GL_DEPTH_TEST);
                GLES30.glDepthFunc(GLES30.GL_LEQUAL);
                
                GLES30.glEnable(GLES30.GL_CULL_FACE);
                GLES30.glCullFace(GLES30.GL_BACK);
                
                System.out.println("[ApexRenderSystem] OpenGL ES pipeline successfully configured with mobile fallbacks.");
            }
        } catch (Throwable t) {
            System.err.println("[ApexRenderSystem] WARNING: OpenGL ES optimization settings skipped due to driver restriction: " + t.getMessage());
        }
    }
}
