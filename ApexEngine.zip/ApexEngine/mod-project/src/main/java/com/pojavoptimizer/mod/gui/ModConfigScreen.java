package com.pojavoptimizer.mod.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import com.pojavoptimizer.mod.config.ModConfig;
import com.pojavoptimizer.mod.threading.ChunkUpdateScheduler;

public class ModConfigScreen extends Screen {
    private final Screen parent;
    private final ModConfig config;

    public ModConfigScreen(Screen parent) {
        super(Text.literal("Apex Mod Configuration"));
        this.parent = parent;
        this.config = ModConfig.getInstance();
    }

    @Override
    protected void init() {
        int widthCenter = this.width / 2;
        int startY = 50;
        int rowHeight = 32;

        int maxProcessors = Runtime.getRuntime().availableProcessors();
        this.addDrawableChild(new SliderWidget(widthCenter - 110, startY, 220, 26, 
            Text.literal("CPU Worker Threads: " + config.cpuThreads), (double) (config.cpuThreads - 1) / (maxProcessors - 1)) {
            @Override
            protected void updateMessage() {
                int value = 1 + (int) Math.round(this.value * (maxProcessors - 1));
                this.setMessage(Text.literal("CPU Worker Threads: " + value + " / " + maxProcessors));
            }

            @Override
            protected void applyValue() {
                config.cpuThreads = 1 + (int) Math.round(this.value * (maxProcessors - 1));
            }
        });

        this.addDrawableChild(new SliderWidget(widthCenter - 110, startY + rowHeight, 220, 26, 
            Text.literal("OOM Clear Threshold: " + config.ramUsageThreshold + "%"), (double) (config.ramUsageThreshold - 50) / 40.0) {
            @Override
            protected void updateMessage() {
                int value = 50 + (int) Math.round(this.value * 40.0);
                this.setMessage(Text.literal("OOM Clear Threshold: " + value + "%"));
            }

            @Override
            protected void applyValue() {
                config.ramUsageThreshold = 50 + (int) Math.round(this.value * 40.0);
            }
        });

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Maximize GPU Utilization: " + (config.maximizeGpu ? "ON" : "OFF")),
            button -> {
                config.maximizeGpu = !config.maximizeGpu;
                button.setMessage(Text.literal("Maximize GPU Utilization: " + (config.maximizeGpu ? "ON" : "OFF")));
            }
        ).dimensions(widthCenter - 110, startY + (rowHeight * 2), 220, 26).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Occlusion Culling: " + (config.enableOcclusionCulling ? "ON" : "OFF")),
            button -> {
                config.enableOcclusionCulling = !config.enableOcclusionCulling;
                button.setMessage(Text.literal("Occlusion Culling: " + (config.enableOcclusionCulling ? "ON" : "OFF")));
            }
        ).dimensions(widthCenter - 110, startY + (rowHeight * 3), 220, 26).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Save & Apply Settings"),
            button -> {
                ModConfig.save();
                ChunkUpdateScheduler.initialize(config.cpuThreads);
                com.pojavoptimizer.mod.ApexEngine.enableOcclusionCulling = config.enableOcclusionCulling;
                this.client.setScreen(this.parent);
            }
        ).dimensions(widthCenter - 110, this.height - 40, 220, 30).build());
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        drawCenteredText(matrices, this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
        
        int widthCenter = this.width / 2;
        drawCenteredText(matrices, this.textRenderer, 
            Text.literal("Touch-friendly oversized controls for Mojo / Pojav Launcher"), 
            widthCenter, this.height - 70, 0x55FF55);
            
        super.render(matrices, mouseX, mouseY, delta);
    }
}
